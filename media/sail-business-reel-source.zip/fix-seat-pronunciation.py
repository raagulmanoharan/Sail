"""Force the LETTER A (/eɪ/), retaining the approved scene durations."""
import os
os.environ['OMP_NUM_THREADS']='2'
import json,subprocess
from pathlib import Path
import numpy as np,soundfile as sf,onnxruntime as ort
from kokoro_onnx import Kokoro
P=Path(__file__).parent;SR=24000
opt=ort.SessionOptions();opt.intra_op_num_threads=2;opt.inter_op_num_threads=1
session=ort.InferenceSession('/tmp/sail-kokoro/kokoro-v1.0.onnx',sess_options=opt,providers=['CPUExecutionProvider'])
k=Kokoro.from_session(session,'/tmp/sail-kokoro/voices-v1.0.bin')
voice=k.get_voice_style('af_heart')*.8+k.get_voice_style('af_nova')*.2
segment,sr=sf.read(P/'assets/narration.wav');assert sr==SR
meta=json.loads((P/'timeline.json').read_text());audit=[]
for scene in meta['scenes']:
 if scene['id'] not in ['range','close']:continue
 phonemes=k.tokenizer.phonemize(scene['text'],'en-us')
 fixed=phonemes.replace('twˈɛlv ɐ','twˈɛlv ˈeɪ')
 assert fixed!=phonemes and 'twˈɛlv ˈeɪ' in fixed
 audio,sr,timing=k.create_timed(fixed,voice=voice,speed=1.06,lang='en-us',is_phonemes=True,sentence_pause=.18,clause_pause=.085)
 folder=P/'assets/pronunciation-fixed';raw=folder/f"{scene['id']}-raw.wav";stretched=folder/f"{scene['id']}-aligned.wav"
 sf.write(raw,audio,sr)
 target=round(scene['voiceDuration']*SR);rate=len(audio)/target
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-af',f'atempo={rate:.10f}',str(stretched)],check=True)
 aligned,sr=sf.read(stretched);aligned=np.pad(aligned,(0,max(0,target-len(aligned))))[:target]
 start=round(scene['voiceStart']*SR);segment[start:start+target]=aligned
 sf.write(stretched,aligned,SR)
 audit.append({'scene':scene['id'],'text':scene['text'],'originalPhonemes':phonemes,'correctedPhonemes':fixed,'seatLetterIPA':'ˈeɪ','durationBeforeAlignment':len(audio)/SR,'approvedVoiceDuration':target/SR,'atempo':rate})
sf.write(P/'assets/narration.wav',segment,SR)
(P/'pronunciation-check.json').write_text(json.dumps({'ok':True,'unchangedTimeline':True,'passages':audit},indent=2));print(json.dumps(audit,indent=2))
