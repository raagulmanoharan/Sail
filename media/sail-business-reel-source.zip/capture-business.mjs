import fs from 'node:fs';
import path from 'node:path';
import puppeteer from 'puppeteer-core';
const root=process.cwd();
let source=fs.readFileSync('index.html','utf8');
const mime={'.woff2':'font/woff2','.svg':'image/svg+xml','.wav':'audio/wav','.js':'text/javascript','.jpg':'image/jpeg','.jpeg':'image/jpeg'};
function data(file){return `data:${mime[path.extname(file)]};base64,${fs.readFileSync(file).toString('base64')}`;}
source=source.replace(/url\((assets\/[^)]+)\)/g,(_,p)=>`url(${data(p)})`);
source=source.replace(/src="(assets\/[^\"]+)"/g,(_,p)=>`src="${data(p)}"`);
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage();await page.setViewport({width:1080,height:1920});
await page.setContent(source,{waitUntil:'load'});await page.evaluate(()=>document.fonts.ready);
const times=[5,13.9,30.7,31.2,32.5,35.8,38.9,41.2,45.5,49.5,50.6,50.79,51,51.5,52.3,58,64,74,78,87.5];
fs.mkdirSync('frames',{recursive:true});const measurements=[];
for(const t of times){
 const state=await page.evaluate(t=>{
  window.__timelines['sail-final'].seek(t,false);
  for(const c of document.querySelectorAll('.caption')){const a=+c.dataset.start,b=a+(+c.dataset.duration);c.style.opacity=t>=a&&t<b?'1':'0';}
  const box=s=>{const e=document.querySelector(s),r=e?.getBoundingClientRect();return r?{x:r.x,y:r.y,w:r.width,h:r.height,opacity:getComputedStyle(e).opacity}:null;};
  return {phoneCount:document.querySelectorAll('#phone').length,phone:box('#phone'),service:box('#service'),button:box('.button'),tap:box('.tap'),request:document.querySelector('.newrequest')?.textContent};
 },t);
 measurements.push({t,...state});
 await page.screenshot({path:`frames/frame-${String(t).replace('.','_')}.png`});
}
fs.writeFileSync('frames/measurements.json',JSON.stringify(measurements,null,2));
console.log(JSON.stringify(measurements.filter(x=>x.t===18.9||x.t===19.3||x.t===55.5),null,2));
await browser.close();
