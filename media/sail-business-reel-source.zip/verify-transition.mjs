import fs from 'node:fs';
import path from 'node:path';
import puppeteer from 'puppeteer-core';
const root=process.cwd();
let source=fs.readFileSync('index.html','utf8');
const mime={'.woff2':'font/woff2','.svg':'image/svg+xml','.wav':'audio/wav','.js':'text/javascript','.jpg':'image/jpeg','.jpeg':'image/jpeg'};
function data(file){return `data:${mime[path.extname(file)]};base64,${fs.readFileSync(file).toString('base64')}`;}
source=source.replace(/url\((assets\/[^)]+)\)/g,(_,p)=>`url(${data(p)})`);
source=source.replace(/src="(assets\/[^\"]+)"/g,(_,p)=>`src="${data(p)}"`);
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage();await page.setViewport({width:1080,height:1920});
await page.setContent(source,{waitUntil:'load'});await page.evaluate(()=>document.fonts.ready);
const times=Array.from({length:125},(_,i)=>50.5+i/60);
fs.mkdirSync('frames',{recursive:true});const measurements=[];
for(const t of times){
 const state=await page.evaluate(t=>{
  window.__timelines['sail-final'].seek(t,false);
  for(const c of document.querySelectorAll('.caption')){const a=+c.dataset.start,b=a+(+c.dataset.duration);c.style.opacity=t>=a&&t<b?'1':'0';}
  const box=s=>{const e=document.querySelector(s),r=e?.getBoundingClientRect();return r?{x:r.x,y:r.y,w:r.width,h:r.height,opacity:getComputedStyle(e).opacity}:null;};
  return {phoneCount:document.querySelectorAll('#seat-sequence .phone').length,architecturePhone:box('#seat-sequence .phone'),phone:box('#phone'),service:box('#service'),button:box('.button'),tap:box('.tap'),request:document.querySelector('.newrequest')?.textContent};
 },t);
 measurements.push({t,...state});
 
}
fs.writeFileSync('frames/transition-measurements.json',JSON.stringify(measurements,null,2));
let maximum=0;for(let i=1;i<measurements.length;i++){const a=measurements[i-1].architecturePhone,b=measurements[i].architecturePhone;maximum=Math.max(maximum,...['x','y','w','h'].map(k=>Math.abs(a[k]-b[k])));if(measurements[i].phoneCount!==1)throw Error('Phone duplicated');}if(maximum>40)throw Error(`Unexpected frame jump ${maximum}px`);console.log(JSON.stringify({ok:true,samples:measurements.length,maxGeometryDeltaPerFrame:maximum,samePhone:true}));
await browser.close();
