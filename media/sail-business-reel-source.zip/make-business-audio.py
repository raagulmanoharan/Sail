"""Offline original reel narration, phoneme-aligned phrase captions and music."""
import os
os.environ['OMP_NUM_THREADS']='2'
import json,re,difflib,hashlib
from pathlib import Path
import numpy as np
import soundfile as sf
import onnxruntime as ort
from kokoro_onnx import Kokoro
ROOT=Path(__file__).resolve().parent
SR=24000
options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
session=ort.InferenceSession(os.environ.get('SAIL_KOKORO_MODEL','/tmp/sail-kokoro/kokoro-v1.0.onnx'),sess_options=options,providers=['CPUExecutionProvider'])
k=Kokoro.from_session(session,os.environ.get('SAIL_KOKORO_VOICES','/tmp/sail-kokoro/voices-v1.0.bin'))
script=json.loads((ROOT/'business-script.json').read_text())
voice=k.get_voice_style('af_heart')*.8+k.get_voice_style('af_nova')*.2
cursor=0.;parts=[];scenes=[];caps=[];phoneme_audit=[]
def silence(seconds):
 global cursor
 parts.append(np.zeros(round(seconds*SR)));cursor+=seconds
for scene in script['scenes']:
 start=cursor;silence(.30 if not scenes else .22);vs=cursor
 text=scene['text']
 cache=ROOT/'assets'/f"voice-{scene['id']}.wav"
 timingcache=ROOT/'assets'/f"voice-{scene['id']}-phonemes.json"
 cachekey=hashlib.sha256((text+'|heart80nova20|1.06|seat-A-ei-v1').encode()).hexdigest()
 keyfile=cache.with_suffix('.key')
 if cache.exists() and timingcache.exists() and keyfile.exists() and keyfile.read_text()==cachekey:
  audio,sr=sf.read(cache);spoken=json.loads(timingcache.read_text())
 else:
  phonemes=k.tokenizer.phonemize(text,'en-us').replace('twˈɛlv ɐ','twˈɛlv ˈeɪ')
  audio,sr,timing=k.create_timed(phonemes,voice=voice,speed=1.06,lang='en-us',is_phonemes=True,sentence_pause=.18,clause_pause=.085)
  spoken=[{'phoneme':t.phoneme,'start':t.start,'end':t.end} for t in timing]
  sf.write(cache,audio,sr);timingcache.write_text(json.dumps(spoken));keyfile.write_text(cachekey)
 parts.append(audio);vd=len(audio)/SR;cursor+=vd
 # Phrase boundaries are taken from model duration output. Prefix phonemization
 # maps text boundaries onto the full spoken phoneme sequence, preserving prosody.
 if not spoken:raise RuntimeError('Duration output required for captions')
 fullphon=''.join(t['phoneme'] for t in spoken)
 words=list(re.finditer(r'\S+',text));groups=[];a=0
 for i,w in enumerate(words):
  count=i-a+1
  if count>=6 or (count>=3 and re.search(r'[.!?:]$',w.group())) or i==len(words)-1:
   groups.append((a,i+1));a=i+1
 if len(groups)>1 and groups[-1][1]-groups[-1][0]==1:
  last=groups.pop();previous=groups.pop();groups.append((previous[0],last[1]))
 def boundary(wordindex):
  if wordindex==0:return spoken[0]['start']
  if wordindex==len(words):return min(vd,spoken[-1]['end'])
  prefix=text[:words[wordindex].start()].rstrip()
  pp=k.tokenizer.known(k.tokenizer.phonemize(prefix,'en-us'))
  # known() string and Timing both include spaces. Select end of matched prefix.
  matcher=difflib.SequenceMatcher(a=pp,b=fullphon[:len(pp)+12],autojunk=False)
  pos=0
  for block in matcher.get_matching_blocks():
   if block.size and block.a+block.size>=len(pp)-2:pos=block.b+block.size;break
  if not pos:pos=min(len(pp),len(spoken))
  return spoken[min(pos,len(spoken)-1)]['start']
 for a,b in groups:
  ca=vs+boundary(a);cb=vs+boundary(b)
  caps.append({'text':text[words[a].start():words[b-1].end()], 'start':round(ca,3),'end':round(cb,3)})
 hold=1.7 if scene['id']=='ending' else .36
 silence(hold)
 scenes.append({'id':scene['id'],'start':round(start,3),'duration':round(cursor-start,3),'text':text,'voiceStart':round(vs,3),'voiceDuration':round(vd,3)})
 print(scene['id'],round(vd,2),round(cursor,2),flush=True)
 narration=np.concatenate(parts)
DURATION=len(narration)/SR
sf.write(ROOT/'assets/business-narration.wav',narration,SR)
(ROOT/'business-timeline.json').write_text(json.dumps({'duration':round(DURATION,3),'total_duration':round(DURATION,3),'scenes':scenes},indent=2))
(ROOT/'business-captions.json').write_text(json.dumps(caps,indent=2))
