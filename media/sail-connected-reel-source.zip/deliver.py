"""Normalize the rendered soundtrack and create a smaller sharing copy."""
from pathlib import Path
import subprocess,json,hashlib
P=Path(__file__).parent
def run(*args):
 subprocess.run(list(args),cwd=P,check=True)
raw=P/'renders/sail-connected-reel-raw.mp4'
if not raw.exists():raise SystemExit('Render the raw HyperFrames MP4 first.')
run('ffmpeg','-v','error','-i',str(raw),'-i','assets/finalmix.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-af','loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=-22.35:measured_TP=-2.48:measured_LRA=2.20:measured_thresh=-32.98:offset=0.65:linear=false','-ar','48000','-c:a','aac','-b:a','192k','-movflags','+faststart','-y','renders/sail-connected-reel.mp4')
run('ffmpeg','-v','error','-i','renders/sail-connected-reel.mp4','-vf','scale=720:1280:flags=lanczos','-c:v','libx264','-preset','fast','-crf','24','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart','-y','renders/sail-connected-reel-share.mp4')
run('ffmpeg','-v','error','-ss','55','-i','renders/sail-connected-reel.mp4','-frames:v','1','-q:v','2','-y','renders/sail-connected-reel-cover.jpg')
results=[]
for name in ['sail-connected-reel.mp4','sail-connected-reel-share.mp4']:
 f=P/'renders'/name
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames,sample_rate','-of','json',str(f)]))
 assert any(s.get('codec_type')=='audio' for s in meta['streams'])
 assert any(s.get('codec_name')=='h264' for s in meta['streams'])
 assert abs(float(meta['format']['duration'])-57.502)<.15
 results.append({'file':name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'metadata':meta})
run('ffmpeg','-v','error','-i','renders/sail-connected-reel.mp4','-f','null','-')
(P/'renders/delivery-verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
