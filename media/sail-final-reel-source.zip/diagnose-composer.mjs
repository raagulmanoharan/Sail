import fs from 'node:fs';
import path from 'node:path';
import puppeteer from 'puppeteer-core';
const root=process.cwd();
let source=fs.readFileSync('index.html','utf8');
const mime={'.woff2':'font/woff2','.svg':'image/svg+xml','.wav':'audio/wav','.js':'text/javascript','.jpg':'image/jpeg','.jpeg':'image/jpeg'};
function data(file){return `data:${mime[path.extname(file)]};base64,${fs.readFileSync(file).toString('base64')}`;}
source=source.replace(/url\((assets\/[^)]+)\)/g,(_,p)=>`url(${data(p)})`);
source=source.replace(/src="(assets\/[^\"]+)"/g,(_,p)=>`src="${data(p)}"`);
const browser=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage();await page.setViewport({width:1080,height:1920});
await page.setContent(source,{waitUntil:'load'});await page.evaluate(()=>document.fonts.ready);
console.log(JSON.stringify(await page.evaluate(()=>[...document.querySelectorAll('.composer')].map(e=>({parent:e.parentElement.className,ancestors:[e.parentElement,e.parentElement.parentElement,e.parentElement.parentElement.parentElement].map(x=>x.id||x.className),html:e.outerHTML.slice(0,300)}))),null,2));
for(const t of [13.9,19,24,27.7,39.5,54,68.5]){console.log(JSON.stringify(await page.evaluate(t=>{window.__timelines['sail-final'].seek(t,false);const b=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}};return {t,oldcomposer:b(document.querySelector('#old-sequence .composer')),oldscreen:b(document.querySelector('#old-sequence .screen')),service:b(document.querySelector('#service')),seatcomposer:b(document.querySelector('#seat-sequence .composer')),seatscreen:b(document.querySelector('#seat-sequence .screen'))};},t)));}
await browser.close();
