import re

def designer_flow(h):
    logo=re.search(r'<div class="sailnode">(.*?)<strong>',h,re.S).group(1)
    a=h.index('<div class="systems">');b=h.index('<div class="closebrand">',a)
    h=h[:a]+'''<div class="systems"><div class="lf-label"><span>01</span><strong>Your business API</strong></div><div class="lf-endpoint"><b>POST</b><code>/documents</code><small>Illustrative endpoint</small></div></div>
<svg class="bridge" data-layout-ignore viewBox="0 0 1080 1920"><defs><marker id="lf-arrow" markerWidth="9" markerHeight="9" refX="6" refY="4.5" orient="auto"><path d="M1 1L6 4.5L1 8" fill="none" stroke="#426aff" stroke-width="1.6"/></marker></defs><path id="routeA" class="route" pathLength="1" d="M540 330V380" marker-end="url(#lf-arrow)"/><path id="routeB" class="route" pathLength="1" d="M540 890V940" marker-end="url(#lf-arrow)"/><path id="routeC" class="route active" pathLength="1" d="M540 330V380"/><path id="routeD" class="route active" pathLength="1" d="M540 890V940"/></svg>
<div class="lf-arrow-label lf-a">Business result</div><div class="lf-arrow-label lf-b">Tool result + linked UI</div>
<div class="socket"><div class="lf-label"><span>02</span><strong>Sail · tool + branded UI</strong></div><div class="sailnode">'''+logo+'''<strong>Sail</strong></div><div class="lf-tool"><div class="lf-toolname"><small>MCP TOOL</small><code>upload_document</code></div><div class="lf-response"><span class="lf-wait">Waiting for business result…</span><code class="lf-result">{ documentId: "DOC-104", status: "received" }</code></div></div><div class="lf-linked">LINKED BRANDED COMPONENT</div><div class="lf-mini"><div class="lf-brand">＋ <strong>Willow Clinic</strong></div><div class="lf-file"><span class="lf-fileicon">▤</span><div><strong>Referral.pdf</strong><small>DOC-104</small></div><div class="lf-status"><span class="lf-pending">Awaiting receipt</span><span class="lf-complete">Uploaded for review ✓</span></div></div><div class="lf-progress"></div></div></div>
<div class="lf-host"><div class="lf-label"><span>03</span><strong>Rendered in your customer’s assistant</strong></div><small class="lf-hostnote">Supported MCP Apps / Apps SDK host</small></div><div class="token token1"></div><div class="token token2"></div><div class="token token3"></div>
'''+h[b:]
    h=h.replace('<strong>Uploaded for review</strong></div></div><h3>', '<strong>Uploaded for review</strong><div class="lf-phone-receipt"><b>Referral.pdf</b><small>DOC-104 · Received</small></div></div></div><h3>',1)
    h=h.replace('<div class="generic" id="upload"><div class="genericbrand">Willow Clinic','<div class="generic" id="upload"><div class="genericbrand">＋ Willow Clinic')
    css='''
/* Three equally aligned stages; one top-to-bottom result spine. */
.systems,.socket,.lf-host{position:absolute;left:140px;width:800px;padding:32px;background:white;border:1px solid #dce3ed;border-radius:24px;box-shadow:none;z-index:2;opacity:0}.systems{top:150px;height:180px}.socket{top:380px;height:510px}.lf-host{top:940px;height:710px;background:#edf0ff70;z-index:0}.lf-label{display:flex;align-items:center;gap:16px;margin:0 0 25px;height:35px}.lf-label>span{font-size:19px!important;color:#536079!important;width:28px}.lf-label strong{font-size:28px;color:#111c32}.lf-endpoint{display:flex;align-items:center;gap:17px;height:44px}.lf-endpoint b{background:#edf0ff;color:#365de5;padding:7px 12px;border-radius:7px;font-size:19px}.lf-endpoint code{font-size:29px}.lf-endpoint small{margin-left:auto;color:#536079;font-size:18px}.sailnode{position:absolute;right:32px;left:auto;top:27px;width:110px;height:43px;background:none;box-shadow:none;border:0;padding:0;display:flex;flex-direction:row;gap:8px;justify-content:flex-end;opacity:0}.sailnode svg{width:33px;height:33px;color:#111c32;fill:#111c32}.sailnode strong{font-size:28px;color:#111c32}.lf-tool{background:#f2f5fa;border-radius:15px;padding:19px 22px}.lf-toolname{display:flex;gap:18px;align-items:center}.lf-toolname small{font-size:17px;letter-spacing:1px;color:#536079}.lf-toolname code{font-size:26px}.lf-response{position:relative;height:43px;margin-top:15px}.socket .lf-wait{font-size:23px;color:#536079}.lf-result{font-size:22px;position:absolute;left:0;top:0;color:#27685d;opacity:0;white-space:nowrap}.lf-linked{font-size:17px;letter-spacing:1.5px;color:#536079;margin:24px 0 14px}.lf-mini{height:190px;border:1px solid #dce3ed;border-radius:17px;overflow:hidden;background:#fff;box-shadow:0 12px 24px #111c3209}.lf-brand{height:61px;background:#edf5f2;padding:17px 24px;font-size:26px;color:#27685d;display:flex;gap:13px;align-items:center}.lf-file{display:flex;gap:20px;align-items:center;padding:23px 24px}.socket .lf-fileicon{font-size:34px;color:#765de5;background:#edf0ff;padding:3px 10px;border-radius:8px}.lf-file strong{font-size:26px}.lf-file small{font-size:20px;color:#536079;display:block;margin-top:7px}.lf-status{margin-left:auto;width:255px;position:relative;height:28px}.socket .lf-status span{font-size:23px;color:#536079}.socket .lf-status .lf-complete{position:absolute;left:0;top:0;opacity:0;color:#27685d}.lf-progress{height:5px;background:#27685d;margin:0 24px;transform-origin:0 50%}.lf-hostnote{display:block;font-size:20px;color:#536079;margin-top:-8px}.lf-arrow-label{position:absolute;left:575px;font-size:18px;color:#536079;opacity:0;z-index:3}.lf-a{top:344px}.lf-b{top:904px}.bridge{z-index:1}.route{stroke:#426aff;stroke-width:4;stroke-dasharray:1;stroke-dashoffset:1;fill:none}.route.active{stroke:#426aff;stroke-width:5}.token{left:529px;top:319px;width:22px;height:22px;border-radius:50%;padding:0;background:#426aff;border:0;z-index:5}.token3{top:879px;background:#765de5}#upload .genericbrand{background:#edf5f2;color:#27685d;padding:18px 24px;margin:-28px -28px 22px;height:98px}#upload .filezone{background:white;border:1px solid #dce3ed}#upload .received{background:white}.lf-phone-receipt{margin-top:18px;border-top:1px solid #dce3ed;padding-top:17px}.lf-phone-receipt b{font-size:27px;display:block}.lf-phone-receipt small{font-size:23px;display:block;margin-top:7px;color:#536079}
'''
    h=h.replace('</style>',css+'</style>')
    a=h.index('// Data and branded presentation');b=h.index('// Restore the hotel',a)
    h=h[:a]+'''// Linear result path: business result -> MCP tool + linked UI -> assistant renderer.
tl.set('.lf-progress',{scaleX:0},0);
tl.to('#upload .received,#upload h3,#upload p',{opacity:0,duration:.2},31.2);
tl.to('#upload .file-preview,#upload .uploadbar',{opacity:1,duration:.2},31.2);
tl.set('#upload .uploadbar',{scaleX:0,transformOrigin:'0 50%'},31.2);
tl.to('#phone',{scale:.4,x:0,y:523,duration:1.5,ease:'power3.inOut'},31.2);
tl.to('.systems',{opacity:1,duration:.5},31.8);tl.from('.lf-endpoint',{clipPath:'inset(0 100% 0 0)',duration:.6,ease:'power2.out'},32);
tl.to('.bridge',{opacity:1,duration:.3},32.6);tl.to('#routeA',{strokeDashoffset:0,duration:.6},32.8);tl.to('.lf-a',{opacity:1,duration:.4},33);
tl.to('.socket',{opacity:1,duration:.5},33.5);tl.from('.lf-tool',{clipPath:'inset(0 100% 0 0)',duration:.65,ease:'power3.out'},33.7);tl.from('.lf-mini',{clipPath:'inset(0 0 100% 0)',duration:.7,ease:'power2.inOut'},34.5);
tl.to('#routeB',{strokeDashoffset:0,duration:.6},35.2);tl.to('.lf-b,.lf-host',{opacity:1,duration:.5},35.4);
tl.fromTo('.sailnode',{opacity:0},{opacity:1,duration:.6,immediateRender:false},38.75);
tl.to('.token1',{opacity:1,duration:.12},39.6);tl.to('.token1',{y:50,duration:.65,ease:'power2.inOut'},39.72);tl.to('.token1',{opacity:0,duration:.12},40.37);
tl.to('.lf-wait',{opacity:0,duration:.25},40.4);tl.to('.lf-result',{opacity:1,duration:.35},40.65);
tl.to('.lf-progress',{scaleX:1,duration:.8,ease:'power2.inOut'},41.15);tl.to('.lf-pending',{opacity:0,duration:.2},41.75);tl.to('.lf-complete',{opacity:1,duration:.3},41.95);
tl.to('.token3',{opacity:1,duration:.1},42.4);tl.to('.token3',{y:50,duration:.65,ease:'power2.inOut'},42.5);tl.to('.token3',{opacity:0,duration:.15},43.15);
tl.to('#upload .uploadbar',{scaleX:1,duration:.8,ease:'power2.inOut'},42.6);tl.to('#upload .file-preview,#upload .uploadbar',{opacity:0,duration:.2},43.4);tl.to('#upload .received,#upload h3,#upload p',{opacity:1,duration:.35},43.6);
'''+h[b:]
    h=h.replace("tl.to('.socket span',{opacity:0,duration:.25},38.5);",'')
    a=h.index('// Restore the hotel');b=h.index("tl.to('#phone',{scale:1",a)
    block=h[a:b]
    block=re.sub(r",(43\.4|43\.6|44\.1|44\.15|44\.6|44\.2)\);",lambda m:','+str(round(float(m.group(1))+2.9,2))+');',block)
    h=h[:a]+block+h[b:]
    h=h.replace("duration:.65,immediateRender:false},47.5);","duration:.45,immediateRender:false},47.05);")
    for old in [".systems,.bridge,.socket,.sailnode,.componentstack'",".systems,.bridge,.socket,.sailnode,.adapter'"]:
        h=h.replace(old,".systems,.bridge,.socket,.sailnode,.lf-host,.lf-arrow-label'")
    return h
