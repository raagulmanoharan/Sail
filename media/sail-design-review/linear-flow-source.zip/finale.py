def finale(h):
    h=h.replace('Be there when your customers need you.','Make the moment yours.')
    h=h.replace('<div class="payoff payoff-book">','<div class="final-aura" data-layout-ignore></div><svg class="final-links" data-layout-ignore viewBox="0 0 1080 1920"><path class="final-route" pathLength="1" d="M245 800C355 800 400 860 540 900C710 950 750 950 850 970M245 1240C360 1240 420 1110 540 1080C700 1080 750 1310 850 1310"/></svg><div class="payoff payoff-book">')
    h=h.replace('Stay confirmed','You’re going to Barcelona.').replace('Order placed','A great find. All yours.').replace('Ready for review','One less thing.')
    h=h.replace('</div>\n</div>', '</div>\n</div>',1)
    marker='</div>CAPTIONS'
    # Captions have been expanded already: insert the fourth completed experience in the scene container.
    pos=h.index('</div><div id="caption0"')
    h=h[:pos]+'''<div class="payoff payoff-seat"><div class="seat-mini"><span>11A</span><span class="chosen">12A ✓</span><span>13A</span></div><div><strong>A window. Just for you.</strong><small>Northstar Air · Seat confirmed</small></div></div>'''+h[pos:]
    css='''
.phone{z-index:2}.closeword{z-index:5;left:125px;top:145px;width:830px;font-size:86px;line-height:1.04;letter-spacing:-4px;color:#111c32}.closebrand{z-index:5;left:430px;top:1490px;font-size:70px;gap:12px}.closebrand svg{width:80px;height:80px}.final-aura{z-index:0;position:absolute;left:40px;top:400px;width:1000px;height:1040px;border-radius:50%;background:radial-gradient(ellipse,#ffffff 0%,#dceafa 42%,#cbd1ff66 64%,#f2f5fa00 73%);opacity:0}.final-links{z-index:1;position:absolute;inset:0;width:100%;height:100%;opacity:0;pointer-events:none}.final-route{stroke:#b9c4f4;stroke-width:6;fill:none;stroke-dasharray:1;stroke-dashoffset:1;stroke-linecap:round}.payoff{width:340px;border-radius:25px;box-shadow:0 25px 55px #111c3230,0 3px 8px #111c320a;border:1px solid #dce3ed}.payoff img{height:195px}.payoff>div:not(.payoff-document):not(.seat-mini){padding:21px 22px}.payoff strong{font-size:28px;line-height:1.14;margin-right:34px}.payoff small{font-size:20px;margin-top:11px}.payoff-check{width:29px;height:29px;right:18px;top:22px;font-size:21px}.payoff-book{left:35px;top:550px;width:275px}.payoff-order{left:765px;top:785px;width:285px}.payoff-file{left:35px;top:1120px;width:275px}.payoff-document{height:130px;background:#e7ebff}.payoff-document svg{width:72px;height:90px}.payoff-seat{left:760px;top:1240px;width:285px}.seat-mini{display:flex;gap:10px;padding:22px 18px;background:#edf0ff;align-items:center;justify-content:center;font-size:18px;color:#536079}.seat-mini span{padding:13px 8px;border-radius:10px;background:white}.seat-mini .chosen{background:#1c3246;color:white;font-size:21px}
'''
    h=h.replace('</style>',css+'</style>')
    a=h.index("tl.to('#phone',{scale:.58");b=h.index('window.__timelines',a)
    h=h[:a]+'''// The same conversation becomes a constellation of completed customer moments.
tl.to('#phone',{scale:.68,y:110,duration:1.2,ease:'power3.inOut'},54.1);
tl.fromTo('.final-aura',{opacity:0,scale:.8},{opacity:1,scale:1,duration:1.2,ease:'sine.out'},54.15);
tl.to('.final-links',{opacity:1,duration:.4},54.35);tl.to('.final-route',{strokeDashoffset:0,duration:1.35,ease:'power2.inOut'},54.4);
tl.fromTo('.payoff-book',{opacity:0,scale:.62,x:160,y:140,rotation:0},{opacity:1,scale:1,x:0,y:0,rotation:-5,duration:1,ease:'power4.out'},54.35);
tl.fromTo('.payoff-order',{opacity:0,scale:.62,x:-170,y:-40,rotation:0},{opacity:1,scale:1,x:0,y:0,rotation:5,duration:1,ease:'power4.out'},54.5);
tl.fromTo('.payoff-file',{opacity:0,scale:.62,x:160,y:-100,rotation:0},{opacity:1,scale:1,x:0,y:0,rotation:-3,duration:.95,ease:'power4.out'},54.65);
tl.fromTo('.payoff-seat',{opacity:0,scale:.62,x:-150,y:-150,rotation:0},{opacity:1,scale:1,x:0,y:0,rotation:3,duration:.95,ease:'power4.out'},54.8);
tl.fromTo('.closeword',{opacity:0,y:28,clipPath:'inset(0 0 100% 0)'},{opacity:1,y:0,clipPath:'inset(0 0 0% 0)',duration:.8,ease:'power3.out'},54.95);
tl.fromTo('.closebrand',{opacity:0,scale:.9},{opacity:1,scale:1,duration:.6,ease:'power3.out'},55.4);
'''+h[b:]
    return h
