# Linear architecture revision

Three consistently aligned containers show one result-delivery chain. Each uses the same 800px width, 32px padding, internal numbered label and quiet outline.

1. **Your business API:** illustrative POST /documents.
2. **Sail · tool + branded UI:** MCP tool upload_document, exact business result `{ documentId: "DOC-104", status: "received" }`, linked Willow Clinic component with Referral.pdf, DOC-104 and Uploaded for review.
3. **Rendered in your customer’s assistant:** a supported MCP Apps / Apps SDK host and the same persistent phone, displaying the same document receipt.

The two connectors are short straight vertical arrows with visible heads. Labels explicitly identify a business result and a tool result plus linked UI. This is the result-delivery topology; it does not claim that an upload request originates in the business API. The assistant host loads the linked branded UI associated with the MCP tool. Uploaded for review means received intake, not clinical approval.

Motion follows a single cause: business result arrives, MCP tool exposes its structured receipt, linked component resolves, then the assistant renders that same receipt. Quiet early states are pending, and completed states consistently share DOC-104. No elbows, perimeter loops, disconnected adapters or floating labels outside stage headers.

Narration, duration and the one existing phone remain unchanged. Native HTML/SVG and deterministic GSAP only.
