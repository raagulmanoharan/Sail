# Sail — continuous service object
Reference palette: warm white #f2f5fa, ice #dceafa, lavender #cbd1ff, navy #111c32, action #426aff. Meridian navy #1c3246, linen #e8e0d2 and gold #bd965a. Locally bundled DM Sans regular/bold. UI 28–40px, captions 43px; data tabular.

A single silver phone persists for the entire reel. One branded service shell grows out of a recommendation, unfolds rooms, responds to date selection and receives explicit confirmation. Its interior changes into catalogue, seat and document controls. Camera retreats to expose the business-side circuit; Sail closes the gap and transports component tokens back to the original phone. That same service is recolored as a physical brandability demonstration. Do not duplicate devices, crossfade whole scenes, bounce everything, animate ambient floating, overlay a footer paragraph, or imply universal integrations.

Hero positions are static CSS. All temporal properties are on one deterministic paused GSAP timeline, registered synchronously. Real hotel and product photographs are bundled locally with source records. No generated imagery. Transform-only camera movement and masked UI state replacements. No CSS animation or translate/scale transform on GSAP targets. Persistent mounted DOM avoids late clip state resets.

Revision: plain sourced text recommendation precedes branded interactive UI. Compact, content-sized cards with synchronized customer requests. Technical architecture separates connected actions, branded UI and assistant adapters. Closing payoff uses completed experiences with photographic depth.
